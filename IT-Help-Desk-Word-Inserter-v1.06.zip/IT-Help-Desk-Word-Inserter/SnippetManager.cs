using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Threading;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyVersion("1.6.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.6.0.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("1.06")]

namespace SnippetManager {
    [DataContract] public class Snippet {
        [DataMember] public string Id = Guid.NewGuid().ToString();
        [DataMember] public string Title;
        [DataMember] public string Category;
        [DataMember] public string Text;
        [DataMember] public string Trigger;
        public override string ToString() { return Title + (String.IsNullOrEmpty(Trigger) ? "" : "   [" + Trigger + "]"); }
    }
    public sealed class MergeResult {
        public Store Collection; public int Added; public int Skipped;
        public List<string> Conflicts=new List<string>();
    }
    [DataContract] public class Store {
        [DataMember] public int Version = 1;
        [DataMember] public List<string> Categories = new List<string>();
        [DataMember] public List<Snippet> Snippets = new List<Snippet>();
        public static Store CreateSamples() {
                var data=new Store(); data.Categories.AddRange(new [] {"Intake","Troubleshooting","User Updates","Escalation","Resolution"});
                data.Snippets.Add(new Snippet {Title="New incident intake",Category="Intake",Trigger=";intake",Text="Reported by: [User Name]\r\nContact: [Email or Extension]\r\nDevice / asset: [Device Name]\r\nLocation: [Location]\r\nIssue: [Issue Description]\r\nStarted: [Date and Time]\r\nImpact: [Users Affected / Business Impact]\r\nError message: [Exact Error Message]\r\nRecent changes: [Recent Changes or None Reported]"});
                data.Snippets.Add(new Snippet {Title="Impact and urgency",Category="Intake",Trigger=";impact",Text="Impact: [Single User / Department / Multiple Locations]\r\nUrgency: [Time Sensitivity]\r\nAffected service: [Service Name]\r\nWorkaround available: [Yes / No - Details]\r\nPriority assigned: [Priority per Service Desk Policy]\r\nReason: [Business Impact and Urgency Rationale]"});
                data.Snippets.Add(new Snippet {Title="Request more information",Category="Intake",Trigger=";details",Text="Hello [User Name],\r\nTo investigate incident [Ticket Number], please provide the exact error message, when the issue began, your device name, and whether anyone else is affected. Please do not send passwords or authentication codes.\r\nThank you,\r\n[Technician Name]"});
                data.Snippets.Add(new Snippet {Title="Reproduction details",Category="Intake",Trigger=";repro",Text="Steps to reproduce:\r\n1. [First Step]\r\n2. [Second Step]\r\n3. [Third Step]\r\nExpected result: [Expected Behavior]\r\nActual result: [Observed Behavior]\r\nFrequency: [Always / Intermittent]\r\nEvidence: [Approved Screenshot or Log Reference]"});
                data.Snippets.Add(new Snippet {Title="Acknowledgement",Category="Intake",Trigger=";ack",Text="Hello [User Name],\r\nWe have received incident [Ticket Number] regarding [Issue Summary]. The help desk will review the issue and provide an update by [Next Update Time].\r\n[Technician Name]"});
                data.Snippets.Add(new Snippet {Title="Troubleshooting work notes",Category="Troubleshooting",Trigger=";trouble",Text="Symptoms verified: [Observed Symptoms]\r\nChecks performed: [Troubleshooting Performed]\r\nResults: [Result of Each Check]\r\nChanges made: [Approved Changes or None]\r\nCurrent status: [Current Status]\r\nNext action: [Next Action]\r\nTechnician / time: [Technician Name / Date and Time]"});
                data.Snippets.Add(new Snippet {Title="Connectivity checks",Category="Troubleshooting",Trigger=";network",Text="Connection type: [Wi-Fi / Ethernet / VPN]\r\nScope: [Affected Users and Devices]\r\nChecks performed: [Adapter Status / Approved Connectivity Tests / Service Status]\r\nResults: [Findings]\r\nActions taken: [Approved Actions]\r\nConnectivity retested: [Result]\r\nNext action: [Next Step]"});
                data.Snippets.Add(new Snippet {Title="Access or account issue",Category="Troubleshooting",Trigger=";access",Text="Affected account / service: [Approved Identifier / Service]\r\nIdentity verification: [Completed per Approved Procedure / Pending]\r\nObserved error: [Error Message]\r\nAccount status checked: [Findings]\r\nAction taken: [Approved Reset / Unlock / Escalation]\r\nUser verification: [Result]\r\nNo passwords or authentication codes recorded in this ticket."});
                data.Snippets.Add(new Snippet {Title="Application investigation",Category="Troubleshooting",Trigger=";appcheck",Text="Application / version: [Application Name / Version]\r\nAffected workflow: [Workflow]\r\nReproduction result: [Result]\r\nChecks performed: [Configuration / Approved Logs / Service Health]\r\nFindings: [Findings]\r\nAction taken: [Approved Action]\r\nRetest result: [Result]"});
                data.Snippets.Add(new Snippet {Title="Hardware investigation",Category="Troubleshooting",Trigger=";hardware",Text="Device / asset: [Device Name / Asset ID]\r\nReported fault: [Fault]\r\nChecks performed: [Power / Cables / Peripherals / Approved Diagnostics]\r\nResults: [Findings]\r\nAction taken: [Action]\r\nReplacement or repair needed: [Details / None]\r\nNext step: [Next Step]"});
                data.Snippets.Add(new Snippet {Title="Progress update",Category="User Updates",Trigger=";update",Text="Hello [User Name],\r\nFor incident [Ticket Number], we have completed [Checks or Actions]. The current status is [Status]. Our next step is [Next Step]. We will provide another update by [Next Update Time].\r\n[Technician Name]"});
                data.Snippets.Add(new Snippet {Title="Awaiting user response",Category="User Updates",Trigger=";waiting",Text="Hello [User Name],\r\nWe are awaiting [Required Information or Test Result] to continue incident [Ticket Number]. Please reply when available.\r\nCurrent workaround: [Workaround / None Available]\r\nNext follow-up: [Date and Time]\r\n[Technician Name]"});
                data.Snippets.Add(new Snippet {Title="Workaround provided",Category="User Updates",Trigger=";workaround",Text="Hello [User Name],\r\nWhile we investigate [Issue], you can use this temporary workaround: [Approved Workaround Steps].\r\nLimitations: [Known Limitations]\r\nPlease let us know whether it allows you to continue working.\r\nIncident: [Ticket Number]"});
                data.Snippets.Add(new Snippet {Title="Schedule remote support",Category="User Updates",Trigger=";remote",Text="Hello [User Name],\r\nPlease provide a convenient time for a remote support session for incident [Ticket Number]. We will use [Approved Support Tool] and obtain your consent before connecting.\r\nAvailability: [Proposed Times and Time Zone]\r\n[Technician Name]"});
                data.Snippets.Add(new Snippet {Title="Service restored notification",Category="User Updates",Trigger=";restored",Text="Hello [User Name],\r\nService for [Affected Service] has been restored following [Action Taken]. Please test [Relevant Function] and confirm that you can work normally.\r\nIncident: [Ticket Number]\r\n[Technician Name]"});
                data.Snippets.Add(new Snippet {Title="Escalation handoff",Category="Escalation",Trigger=";escalate",Text="Incident: [Ticket Number]\r\nEscalated to: [Team]\r\nReason: [Reason for Escalation]\r\nBusiness impact / priority: [Impact / Priority]\r\nSymptoms and scope: [Summary]\r\nTroubleshooting and results: [Steps and Results]\r\nEvidence references: [Approved Logs / Screenshots]\r\nWorkaround: [Workaround / None]\r\nRequested action: [Action Needed]\r\nUser contact / availability: [Approved Contact / Availability]"});
                data.Snippets.Add(new Snippet {Title="Vendor case",Category="Escalation",Trigger=";vendor",Text="Vendor / product: [Vendor / Product]\r\nVendor case number: [Case Number]\r\nInternal incident: [Ticket Number]\r\nIssue summary: [Summary]\r\nDiagnostics shared: [Approved Diagnostic References]\r\nVendor response: [Response]\r\nNext action / owner: [Action / Owner]\r\nNext update: [Date and Time]"});
                data.Snippets.Add(new Snippet {Title="Related service outage",Category="Escalation",Trigger=";outage",Text="Affected service: [Service]\r\nKnown outage reference: [Major Incident / Status Reference]\r\nUsers / locations affected: [Scope]\r\nSymptoms: [Symptoms]\r\nLinked incident: [Ticket Number]\r\nWorkaround: [Approved Workaround / None]\r\nCommunications sent: [Audience / Time]\r\nNext update: [Time]"});
                data.Snippets.Add(new Snippet {Title="Suspected security incident",Category="Escalation",Trigger=";security",Text="Potential security concern: [Observed Facts]\r\nDetection time: [Date and Time]\r\nAffected asset / account: [Approved Identifier]\r\nActions taken: [Actions per Approved Security Procedure]\r\nEscalated to: [Security Team / Approved Channel]\r\nEvidence location: [Approved Evidence Reference]\r\nFurther actions pending: [Security Team Direction]\r\nAvoid including credentials or unnecessary sensitive data."});
                data.Snippets.Add(new Snippet {Title="Shift handover",Category="Escalation",Trigger=";handover",Text="Incident: [Ticket Number]\r\nCurrent owner / next owner: [Names or Teams]\r\nCurrent status: [Status]\r\nCompleted actions: [Summary]\r\nPending actions: [Actions]\r\nDependencies: [Dependencies]\r\nUser expectation / next update: [Details]\r\nImportant references: [References]"});
                data.Snippets.Add(new Snippet {Title="Resolution notes",Category="Resolution",Trigger=";resolve",Text="Issue: [Issue Summary]\r\nCause: [Confirmed Cause / Not Determined]\r\nResolution: [Actions Taken]\r\nVerification: [Tests and Results]\r\nUser confirmation: [Confirmation / Awaiting Response]\r\nResolved by / at: [Technician Name / Date and Time]\r\nFollow-up required: [Details / None]"});
                data.Snippets.Add(new Snippet {Title="Closure message",Category="Resolution",Trigger=";close",Text="Hello [User Name],\r\nIncident [Ticket Number] for [Issue] has been resolved by [Resolution Summary]. Verification: [Test Result / User Confirmation]. We are closing the ticket according to [Closure Policy]. If the issue returns, please contact the help desk and reference this ticket.\r\n[Technician Name]"});
                data.Snippets.Add(new Snippet {Title="Password reset completed",Category="Resolution",Trigger=";resetdone",Text="Identity verified per approved procedure: [Verification Completed]\r\nAffected account / service: [Approved Identifier / Service]\r\nReset or unlock completed: [Action and Time]\r\nUser sign-in tested: [Result]\r\nAdditional steps advised: [Approved Guidance / None]\r\nNo password or authentication code recorded."});
                data.Snippets.Add(new Snippet {Title="Knowledge article reference",Category="Resolution",Trigger=";kb",Text="Issue / symptom: [Summary]\r\nKnowledge article: [Article Title / Approved Link]\r\nApplicable steps followed: [Steps]\r\nOutcome: [Result]\r\nArticle feedback or update needed: [Details / None]"});
                data.Snippets.Add(new Snippet {Title="Follow-up confirmation",Category="Resolution",Trigger=";confirm",Text="Hello [User Name],\r\nFollowing the changes for incident [Ticket Number], please confirm whether [Affected Function] is now working as expected. If the issue continues, please describe what you see and when it occurs.\r\n[Technician Name]"});
            return data;
        }
        // Build a new collection without changing either input. Existing triggers win.
        public static MergeResult Merge(Store current,Store incoming) {
            var result=new MergeResult();var merged=new Store();
            merged.Categories.AddRange(current.Categories);merged.Snippets.AddRange(current.Snippets);
            var ids=new HashSet<string>(current.Snippets.Select(x=>x.Id));
            var triggers=new HashSet<string>(current.Snippets.Where(x=>!String.IsNullOrEmpty(x.Trigger)).Select(x=>x.Trigger),StringComparer.OrdinalIgnoreCase);
            foreach(var category in incoming.Categories) {
                if(!merged.Categories.Any(x=>String.Equals(x,category,StringComparison.OrdinalIgnoreCase)))merged.Categories.Add(category);
            }
            foreach(var snippet in incoming.Snippets) {
                string category=merged.Categories.First(x=>String.Equals(x,snippet.Category,StringComparison.OrdinalIgnoreCase));
                if(merged.Snippets.Any(x=>String.Equals(x.Title,snippet.Title,StringComparison.OrdinalIgnoreCase) && String.Equals(x.Category,category,StringComparison.OrdinalIgnoreCase) && x.Text==snippet.Text && String.Equals(x.Trigger??"",snippet.Trigger??"",StringComparison.OrdinalIgnoreCase))) {result.Skipped++;continue;}
                // Repeat imports must not multiply copies whose conflicting trigger was cleared.
                bool conflict=!String.IsNullOrEmpty(snippet.Trigger) && triggers.Contains(snippet.Trigger);
                if(conflict && merged.Snippets.Any(x=>String.Equals(x.Title,snippet.Title,StringComparison.OrdinalIgnoreCase) && String.Equals(x.Category,category,StringComparison.OrdinalIgnoreCase) && x.Text==snippet.Text && String.IsNullOrEmpty(x.Trigger))) {result.Skipped++;continue;}
                string id=snippet.Id;if(String.IsNullOrEmpty(id) || !ids.Add(id)) {do {id=Guid.NewGuid().ToString();}while(!ids.Add(id));}
                string trigger=snippet.Trigger??"";
                if(trigger.Length>0 && !triggers.Add(trigger)) {result.Conflicts.Add(snippet.Title+" ["+trigger+"]");trigger="";}
                merged.Snippets.Add(new Snippet {Id=id,Title=snippet.Title,Category=category,Text=snippet.Text,Trigger=trigger});result.Added++;
            }
            if(merged.Categories.Count>1000 || merged.Snippets.Count>20000)throw new Exception("Merging would exceed the collection limit of 1,000 categories or 20,000 snippets. Nothing was changed.");
            result.Collection=merged;return result;
        }

        public static Store Read(string path) {
            if (new FileInfo(path).Length > 10 * 1024 * 1024) throw new Exception("The file exceeds the 10 MB limit.");
            Store data;
            using (var stream = File.OpenRead(path)) data = (Store)new DataContractJsonSerializer(typeof(Store)).ReadObject(stream);
            if (data == null || data.Version != 1 || data.Categories == null || data.Snippets == null) throw new Exception("This is not a supported snippet backup.");
            if (data.Categories.Count > 1000 || data.Snippets.Count > 20000) throw new Exception("The backup contains too many items.");
            data.Categories = data.Categories.Where(c => !String.IsNullOrWhiteSpace(c)).Select(c => c.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            foreach (var s in data.Snippets) {
                if (s == null || String.IsNullOrWhiteSpace(s.Title) || String.IsNullOrWhiteSpace(s.Category) || s.Text == null) throw new Exception("The backup contains an invalid snippet.");
                s.Category = s.Category.Trim();
                var existing = data.Categories.FirstOrDefault(c => String.Equals(c, s.Category, StringComparison.OrdinalIgnoreCase));
                if (existing == null) data.Categories.Add(s.Category); else s.Category = existing;
            }
            if (data.Categories.Count == 0) data.Categories.Add("General");
            var ids = new HashSet<string>();
            foreach(var s in data.Snippets) if(String.IsNullOrEmpty(s.Id) || !ids.Add(s.Id)) {s.Id=Guid.NewGuid().ToString();ids.Add(s.Id);}
            var triggers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var s in data.Snippets) {
                s.Trigger = (s.Trigger ?? "").Trim();
                if (s.Trigger.Length > 40 || s.Trigger.Any(c => c < 33 || c > 126) || (s.Trigger.Length > 0 && !triggers.Add(s.Trigger))) throw new Exception("Triggers must be unique, at most 40 characters, and contain only printable ASCII characters without spaces.");
            }
            return data;
        }
        public void Write(string path) {
            string temp = path + ".tmp";
            try {
                using (var stream = new FileStream(temp, FileMode.Create, FileAccess.Write)) {
                    new DataContractJsonSerializer(typeof(Store)).WriteObject(stream, this);
                    stream.Flush(true);
                }
                if (File.Exists(path)) File.Replace(temp, path, path + ".bak"); else File.Move(temp, path);
            } finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }
    internal static class Native {
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint key);
        [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        [DllImport("user32.dll")] public static extern uint SendInput(uint count, INPUT[] inputs, int size);
        public delegate IntPtr HookProc(int code, IntPtr message, IntPtr info);
        [DllImport("user32.dll", SetLastError=true)] public static extern IntPtr SetWindowsHookEx(int id, HookProc proc, IntPtr module, uint thread);
        [DllImport("user32.dll")] public static extern bool UnhookWindowsHookEx(IntPtr hook);
        [DllImport("user32.dll")] public static extern IntPtr CallNextHookEx(IntPtr hook, int code, IntPtr message, IntPtr info);
        [DllImport("kernel32.dll", CharSet=CharSet.Auto)] public static extern IntPtr GetModuleHandle(string name);
        [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int key);
        [DllImport("user32.dll")] public static extern short GetKeyState(int key);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);
        [DllImport("user32.dll")] public static extern IntPtr GetKeyboardLayout(uint thread);
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int ToUnicodeEx(uint key, uint scan, byte[] state, StringBuilder text, int size, uint flags, IntPtr layout);
        [StructLayout(LayoutKind.Sequential)] public struct HOOKKEY {public uint key,scan,flags,time;public UIntPtr extra;}
        [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public UNION data; }
        [StructLayout(LayoutKind.Explicit)] public struct UNION {
            [FieldOffset(0)] public KEYBOARD keyboard;
            [FieldOffset(0)] public MOUSE mouse;
        }
        [StructLayout(LayoutKind.Sequential)] public struct KEYBOARD { public ushort key, scan; public uint flags, time; public UIntPtr extra; }
        [StructLayout(LayoutKind.Sequential)] public struct MOUSE { public int x,y; public uint mouseData,flags,time; public UIntPtr extra; }
        public static bool Key(ushort key,bool up) {
            var input=new INPUT();input.type=1;input.data.keyboard.key=key;
            if(key==0x11)input.data.keyboard.scan=0x1D;
            else if(key==0x56)input.data.keyboard.scan=0x2F;
            else if(key==8)input.data.keyboard.scan=0x0E;
            input.data.keyboard.flags=up ? 2u : 0u;
            return SendInput(1,new INPUT[]{input},Marshal.SizeOf(typeof(INPUT)))==1;
        }
        public static bool Down(int key) {return (GetAsyncKeyState(key)&0x8000)!=0;}
    }
    // Keep the target's message processing between key transitions. Sending a
    // large burst can race modern editors' asynchronous text processing.
    internal sealed class ClipboardInserter : IDisposable {
        readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer();
        readonly IntPtr destination;readonly string text;readonly Func<bool> unchanged;readonly Action<string> finished;
        int remaining,stage,waits;bool ctrlHeld,vHeld,backHeld,disposed;
        public ClipboardInserter(string value,int erase,IntPtr window,Func<bool> stillValid,Action<string> callback) {
            text=value.Replace("\r\n","\n").Replace("\r","\n").Replace("\n","\r\n");
            remaining=erase;destination=window;unchanged=stillValid;finished=callback;
            timer.Interval=25;timer.Tick+=Tick;timer.Start();
        }
        void Tick(object sender,EventArgs args) {
            try {
                if(!Native.IsWindow(destination)||Native.GetForegroundWindow()!=destination||(unchanged!=null&&!unchanged())) {Finish("Insertion stopped because the destination or your input changed.");return;}
                if(stage==0) {
                    if(Native.Down(0x10)||Native.Down(0x11)||Native.Down(0x12)||Native.Down(0x5B)||Native.Down(0x5C)||Native.Down(0x20)) {
                        if(++waits>60)Finish("Insertion stopped. Release the shortcut keys and try again.");return;
                    }
                    Clipboard.SetText(text,TextDataFormat.UnicodeText);stage=1;timer.Interval=60;return;
                }
                if(stage==1) {
                    if(remaining>0) {backHeld=true;Require(Native.Key(8,false));stage=2;timer.Interval=25;return;}
                    stage=3;timer.Interval=120;return;
                }
                if(stage==2) {Require(Native.Key(8,true));backHeld=false;remaining--;stage=1;timer.Interval=25;return;}
                if(stage==3) {ctrlHeld=true;Require(Native.Key(0x11,false));stage=4;timer.Interval=80;return;}
                if(stage==4) {vHeld=true;Require(Native.Key(0x56,false));stage=5;timer.Interval=40;return;}
                if(stage==5) {Require(Native.Key(0x56,true));vHeld=false;stage=6;timer.Interval=80;return;}
                if(stage==6) {Require(Native.Key(0x11,true));ctrlHeld=false;Finish("Insertion sent. Text is also available on the clipboard.");}
            }catch(Exception ex) {Finish("Insertion stopped: "+ex.Message+" Use Copy text and paste manually.");}
        }
        static void Require(bool success) {if(!success)throw new Exception("Windows blocked simulated input.");}
        void Finish(string message) {Dispose();finished(message);}
        public void Dispose() {
            if(disposed)return;disposed=true;timer.Stop();timer.Dispose();
            if(backHeld)Native.Key(8,true);if(vHeld)Native.Key(0x56,true);if(ctrlHeld)Native.Key(0x11,true);
        }
    }
    internal sealed class Autotext : IDisposable {
        readonly MainForm form; readonly Native.HookProc keyboardProc, mouseProc;
        IntPtr keyboardHook,mouseHook,lastWindow; string buffer="";int generation;long lastTime;
        public bool Enabled=true;
        public int Generation {get {return generation;}}
        public bool Available {get {return keyboardHook!=IntPtr.Zero && mouseHook!=IntPtr.Zero;}}
        public Autotext(MainForm owner) {
            form=owner;keyboardProc=Keyboard;mouseProc=Mouse;
            IntPtr module=Native.GetModuleHandle(null);
            keyboardHook=Native.SetWindowsHookEx(13,keyboardProc,module,0);mouseHook=Native.SetWindowsHookEx(14,mouseProc,module,0);
        }
        public void Reset() {buffer="";generation++;}
        IntPtr Mouse(int code,IntPtr message,IntPtr info) {
            if(code>=0 && (message.ToInt32()==0x201 || message.ToInt32()==0x204 || message.ToInt32()==0x207 || message.ToInt32()==0x20A)) Reset();
            return Native.CallNextHookEx(mouseHook,code,message,info);
        }
        IntPtr Keyboard(int code,IntPtr message,IntPtr info) {
            try {
                if(code<0 || !Enabled || !Available) return Native.CallNextHookEx(keyboardHook,code,message,info);
                var k=(Native.HOOKKEY)Marshal.PtrToStructure(info,typeof(Native.HOOKKEY));
                if((k.flags & 0x10)!=0 || (message.ToInt32()!=0x100 && message.ToInt32()!=0x104)) return Native.CallNextHookEx(keyboardHook,code,message,info);
                IntPtr window=Native.GetForegroundWindow();uint process;uint thread=Native.GetWindowThreadProcessId(window,out process);
                if(process==(uint)Process.GetCurrentProcess().Id) {Reset();return Native.CallNextHookEx(keyboardHook,code,message,info);}
                if(window!=lastWindow || Environment.TickCount-lastTime>5000) Reset();lastWindow=window;lastTime=Environment.TickCount;
                if(k.key==0x10 || k.key==0xA0 || k.key==0xA1) return Native.CallNextHookEx(keyboardHook,code,message,info);
                generation++;
                if(Down(0x11)||Down(0x12)||Down(0x5B)||Down(0x5C)||k.key==0x11||k.key==0x12) {buffer="";return Native.CallNextHookEx(keyboardHook,code,message,info);}
                if(k.key==8) {if(buffer.Length>0)buffer=buffer.Substring(0,buffer.Length-1);return Native.CallNextHookEx(keyboardHook,code,message,info);}
                if(k.key==0x20) {
                    Snippet match=form.FindTrigger(buffer);buffer="";
                    if(match!=null) {
                        int stamp=generation;var timer=new System.Windows.Forms.Timer {Interval=35};
                        timer.Tick+=delegate {timer.Stop();timer.Dispose();if(Enabled && generation==stamp && Native.GetForegroundWindow()==window && !Down(0x10) && !Down(0x11) && !Down(0x12)) form.ExpandTrigger(match);};timer.Start();
                    }
                    return Native.CallNextHookEx(keyboardHook,code,message,info);
                }
                var state=new byte[256];for(int i=0;i<256;i++)if(Down(i))state[i]=128;
                state[k.key]=128;state[0x14]=(byte)(Native.GetKeyState(0x14)&1);
                var chars=new StringBuilder(8);int count=Native.ToUnicodeEx(k.key,k.scan,state,chars,8,4,Native.GetKeyboardLayout(thread));
                if(count==1 && chars[0]>=33 && chars[0]<=126) {buffer+=chars[0];if(buffer.Length>40)buffer="";} else buffer="";
            } catch {Reset();}
            return Native.CallNextHookEx(keyboardHook,code,message,info);
        }
        static bool Down(int key) {return (Native.GetAsyncKeyState(key)&0x8000)!=0;}
        public void Dispose() {Enabled=false;Reset();if(keyboardHook!=IntPtr.Zero)Native.UnhookWindowsHookEx(keyboardHook);if(mouseHook!=IntPtr.Zero)Native.UnhookWindowsHookEx(mouseHook);}
    }
    public static class Program {
        public static string BaseDirectory;
        [STAThread] public static void Run(string baseDirectory) {
            BaseDirectory=baseDirectory;
            bool first;
            using (var mutex = new Mutex(true, "Local\\ITHelpDeskWordInserter", out first)) {
                if (!first) { MessageBox.Show("IT Help Desk Word Inserter is already running. Press Ctrl + Alt + Space to open it."); return; }
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm());
            }
        }
    }
    internal class Editor : Form {
        public TextBox TitleBox = new TextBox();
        public ComboBox CategoryBox = new ComboBox();
        public TextBox BodyBox = new TextBox();
        public TextBox TriggerBox = new TextBox();
        public Editor(List<string> categories, Snippet snippet) {
            Text = snippet == null ? "New snippet" : "Edit snippet";
            Size = new Size(640,620); MinimumSize = Size;
            StartPosition = FormStartPosition.CenterParent; Font = new Font("Segoe UI",10);
            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(20), ColumnCount = 1, RowCount = 9 };
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute,26)); panel.RowStyles.Add(new RowStyle(SizeType.Absolute,36));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute,26)); panel.RowStyles.Add(new RowStyle(SizeType.Absolute,36));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute,26)); panel.RowStyles.Add(new RowStyle(SizeType.Absolute,36));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute,26)); panel.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute,48));
            TitleBox.Dock = CategoryBox.Dock = BodyBox.Dock = DockStyle.Fill;
            CategoryBox.DropDownStyle = ComboBoxStyle.DropDownList; CategoryBox.Items.AddRange(categories.Cast<object>().ToArray()); CategoryBox.SelectedIndex = 0;
            BodyBox.Multiline = true; BodyBox.AcceptsReturn = true; BodyBox.AcceptsTab = true; BodyBox.ScrollBars = ScrollBars.Both; BodyBox.WordWrap = false;
            panel.Controls.Add(new Label { Text="Title", AutoSize=true }); panel.Controls.Add(TitleBox);
            panel.Controls.Add(new Label { Text="Category", AutoSize=true }); panel.Controls.Add(CategoryBox);
            TriggerBox.Dock=DockStyle.Fill;TriggerBox.MaxLength=40;
            panel.Controls.Add(new Label {Text="Autotext trigger (optional): type it, then Space",AutoSize=true});panel.Controls.Add(TriggerBox);
            panel.Controls.Add(new Label { Text="Snippet text", AutoSize=true }); panel.Controls.Add(BodyBox);
            var actions = new FlowLayoutPanel { Dock=DockStyle.Fill, FlowDirection=FlowDirection.RightToLeft };
            var save = new Button { Text="Save", Width=100, Height=34 };
            var cancel = new Button { Text="Cancel", Width=100, Height=34, DialogResult=DialogResult.Cancel };
            save.Click += delegate {
                if (String.IsNullOrWhiteSpace(TitleBox.Text) || String.IsNullOrWhiteSpace(BodyBox.Text)) { MessageBox.Show("Enter a title and snippet text."); return; }
                if(TriggerBox.Text.Any(c=>c<33||c>126)) {MessageBox.Show("Use letters, numbers, or ASCII punctuation without spaces. Example: ;intake");return;}
                DialogResult=DialogResult.OK;
            };
            actions.Controls.Add(save); actions.Controls.Add(cancel); panel.Controls.Add(actions); Controls.Add(panel); CancelButton=cancel;
            if (snippet != null) { TitleBox.Text=snippet.Title; CategoryBox.SelectedItem=snippet.Category; BodyBox.Text=snippet.Text;TriggerBox.Text=snippet.Trigger ?? ""; }
        }
    }
    [DataContract] internal sealed class Preferences {
        [DataMember] public bool Dark=true;
        [DataMember] public bool Paused=false;
        [DataMember] public bool AlwaysOnTop=true;
        [DataMember] public bool FloatingVisible=true;
        [DataMember] public List<string> HiddenIds=new List<string>();
        [DataMember] public int MainX=Int32.MinValue, MainY=0, MainWidth=1000, MainHeight=660;
        [DataMember] public int FloatX=Int32.MinValue, FloatY=0, FloatWidth=390, FloatHeight=480;
        public static Preferences Load(string path) {
            if(!File.Exists(path))return new Preferences();
            try {using(var stream=File.OpenRead(path)) {
                var p=(Preferences)new DataContractJsonSerializer(typeof(Preferences)).ReadObject(stream);
                if(p==null)throw new Exception("Empty preferences");
                if(p.HiddenIds==null)p.HiddenIds=new List<string>();return p;
            }} catch {return new Preferences();}
        }
        public void Save(string path) {
            string temp=path+".tmp";
            try {using(var stream=new FileStream(temp,FileMode.Create,FileAccess.Write)) {
                new DataContractJsonSerializer(typeof(Preferences)).WriteObject(stream,this);stream.Flush(true);
            }if(File.Exists(path))File.Replace(temp,path,path+".bak");else File.Move(temp,path);
            }finally {if(File.Exists(temp))File.Delete(temp);}
        }
    }
    internal sealed class PaletteRenderer : ToolStripProfessionalRenderer {
        readonly bool dark;
        public PaletteRenderer(bool value) {dark=value;}
        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e) {
            using(var brush=new SolidBrush(dark ? Color.FromArgb(35,39,47) : Color.White))e.Graphics.FillRectangle(brush,e.AffectedBounds);
        }
        protected override void OnRenderImageMargin(ToolStripRenderEventArgs e) {
            using(var brush=new SolidBrush(dark ? Color.FromArgb(35,39,47) : Color.White))e.Graphics.FillRectangle(brush,e.AffectedBounds);
        }
        protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e) {
            Color color=e.Item.Selected ? (dark ? Color.FromArgb(60,76,95) : Color.FromArgb(217,234,250)) : (dark ? Color.FromArgb(35,39,47) : Color.White);
            using(var brush=new SolidBrush(color))e.Graphics.FillRectangle(brush,new Rectangle(Point.Empty,e.Item.Size));
        }
        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e) {e.TextColor=dark ? Color.FromArgb(235,239,244) : Color.FromArgb(25,33,44);base.OnRenderItemText(e);}
    }
    internal static class Theme {
        public static void Apply(Control control,bool dark) {
            control.BackColor=dark ? Color.FromArgb(31,35,43) : Color.FromArgb(245,248,250);
            control.ForeColor=dark ? Color.FromArgb(235,239,244) : Color.FromArgb(25,33,44);
            if(control is TextBox || control is ListBox || control is ListView || control is ComboBox)control.BackColor=dark ? Color.FromArgb(42,48,59) : Color.White;
            var button=control as Button;if(button!=null) {button.BackColor=dark ? Color.FromArgb(53,66,82) : Color.White;button.FlatStyle=FlatStyle.Flat;button.FlatAppearance.BorderColor=dark ? Color.FromArgb(84,104,128) : Color.FromArgb(165,180,197);}
            var strip=control as ToolStrip;
            if(strip!=null) {strip.Renderer=new PaletteRenderer(dark);foreach(ToolStripItem item in strip.Items)ApplyItem(item,dark);}
            foreach(Control child in control.Controls)Apply(child,dark);
        }
        static void ApplyItem(ToolStripItem item,bool dark) {
            item.BackColor=dark ? Color.FromArgb(35,39,47) : Color.White;
            item.ForeColor=dark ? Color.FromArgb(235,239,244) : Color.FromArgb(25,33,44);
            var dropdown=item as ToolStripDropDownItem;if(dropdown!=null) {dropdown.DropDown.Renderer=new PaletteRenderer(dark);dropdown.DropDown.BackColor=item.BackColor;foreach(ToolStripItem child in dropdown.DropDownItems)ApplyItem(child,dark);}
        }
    }
    internal sealed class FloatingForm : Form {
        readonly MainForm manager;
        readonly ListView list=new ListView {Dock=DockStyle.Fill,View=View.Details,FullRowSelect=true,HideSelection=false,MultiSelect=false};
        readonly Label activity=new Label {Dock=DockStyle.Bottom,Height=30,TextAlign=ContentAlignment.MiddleLeft,Padding=new Padding(8,0,0,0)};
        public FloatingForm(MainForm owner) {
            manager=owner;Text="Snippet titles & triggers";Size=new Size(390,480);MinimumSize=new Size(370,260);Font=new Font("Segoe UI",10);StartPosition=FormStartPosition.CenterScreen;
            list.Columns.Add("Snippet title",235);list.Columns.Add("Auto trigger",115);Controls.Add(list);
            var bar=new FlowLayoutPanel {Dock=DockStyle.Top,Height=48,Padding=new Padding(6)};
            var add=new Button {Text="Add New Snippet",Width=155,Height=32};add.Click+=delegate {manager.NewFromFloating();};bar.Controls.Add(add);
            var manage=new Button {Text="Choose Snippets",Width=145,Height=32};manage.Click+=delegate {manager.ConfigureFloating();};bar.Controls.Add(manage);Controls.Add(bar);Controls.Add(activity);
            var menu=new MenuStrip();var options=new ToolStripMenuItem("Options");
            options.DropDownItems.Add("Include / exclude snippets",null,delegate {manager.ConfigureFloating();});
            var top=new ToolStripMenuItem("Always on top") {CheckOnClick=true,Checked=manager.AlwaysOnTop};top.CheckedChanged+=delegate {manager.SetAlwaysOnTop(top.Checked);};options.DropDownItems.Add(top);
            options.DropDownOpening+=delegate {top.Checked=manager.AlwaysOnTop;};
            options.DropDownItems.Add("Pause / resume autotext",null,delegate {manager.TogglePause();});
            options.DropDownItems.Add("Open main program",null,delegate {manager.OpenMain();});
            options.DropDownItems.Add("Hide floating window",null,delegate {manager.SetFloating(false);});menu.Items.Add(options);Controls.Add(menu);MainMenuStrip=menu;
            FormClosing+=delegate(object sender,FormClosingEventArgs e) {if(e.CloseReason==CloseReason.UserClosing) {e.Cancel=true;manager.SetFloating(false);}};
            list.Resize+=delegate {if(list.ClientSize.Width>120)list.Columns[0].Width=list.ClientSize.Width-119;};
        }
        public void RefreshSnippets(IEnumerable<Snippet> snippets,List<string> hidden) {
            list.BeginUpdate();list.Items.Clear();foreach(var s in snippets.Where(x=>!hidden.Contains(x.Id)).OrderBy(x=>x.Title)) {
                var item=new ListViewItem(s.Title);item.SubItems.Add(String.IsNullOrEmpty(s.Trigger) ? "(none)" : s.Trigger);list.Items.Add(item);
            }list.EndUpdate();
        }
        public void SetActivity(string text) {activity.Text=text;}
    }

    internal class MainForm : Form {
        Store data;
        readonly string dataPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ITHelpDeskWordInserter","snippets.json");
        ComboBox categories = new ComboBox(); TextBox search = new TextBox(); ListBox snippets = new ListBox();
        TextBox preview = new TextBox(); Label status = new Label(); Label title = new Label();
        NotifyIcon tray; IntPtr target = IntPtr.Zero; bool hotkey; bool loading; bool quitting; bool readOnly;
        Autotext autotext;ClipboardInserter insertion;
        Preferences prefs; FloatingForm floating; CheckBox pause; ToolStripMenuItem darkItem, floatItem, pauseItem;
        Label activity=new Label(); bool preferencesReady;
        readonly string prefsPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ITHelpDeskWordInserter","preferences.json");
        public MainForm() {
            Text="IT Help Desk Word Inserter - Version 1.06"; Size=new Size(1000,660); MinimumSize=new Size(850,560);
            Font=new Font("Segoe UI",10); BackColor=Color.FromArgb(245,248,250); StartPosition=FormStartPosition.CenterScreen;
            Directory.CreateDirectory(Path.GetDirectoryName(dataPath));
            prefs=Preferences.Load(prefsPath);
            Icon=LoadIcon();
            if (File.Exists(dataPath)) {
                try { data=Store.Read(dataPath); }
                catch (Exception ex) {
                    readOnly=true; data=new Store(); data.Categories.Add("General");
                    MessageBox.Show("Your saved data could not be opened. It has been preserved. This session is read-only. Close the app and recover snippets.json from snippets.json.bak in:\n" + Path.GetDirectoryName(dataPath) + "\n\n" + ex.Message,"Data recovery required");
                }
            } else {
                data=Store.CreateSamples();
                Persist();
            }
            var root=new TableLayoutPanel {Dock=DockStyle.Fill,Padding=new Padding(20),ColumnCount=1,RowCount=5};
            root.RowStyles.Add(new RowStyle(SizeType.Absolute,64)); root.RowStyles.Add(new RowStyle(SizeType.Absolute,42));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute,44)); root.RowStyles.Add(new RowStyle(SizeType.Percent,100)); root.RowStyles.Add(new RowStyle(SizeType.Absolute,55));
            var heading=new Label {Text="IT Help Desk Word Inserter",Font=new Font("Segoe UI",20,FontStyle.Bold),ForeColor=Color.FromArgb(0,100,110),Dock=DockStyle.Fill}; root.Controls.Add(heading);
            var filter=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=4};
            filter.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,80)); filter.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,215)); filter.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,70)); filter.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            filter.Controls.Add(new Label {Text="Category",AutoSize=true}); categories.Dock=DockStyle.Fill; categories.DropDownStyle=ComboBoxStyle.DropDownList; filter.Controls.Add(categories);
            filter.Controls.Add(new Label {Text="Search",AutoSize=true}); search.Dock=DockStyle.Fill; filter.Controls.Add(search); root.Controls.Add(filter);
            var bar=new FlowLayoutPanel {Dock=DockStyle.Fill};
            AddButton(bar,"New snippet",delegate {Edit(false);}); AddButton(bar,"Edit",delegate {Edit(true);}); AddButton(bar,"Delete",delegate {DeleteSnippet();});
            AddButton(bar,"Categories",delegate {ManageCategories();}); AddButton(bar,"Export",delegate {Export();}); AddButton(bar,"Import",delegate {Import();}); root.Controls.Add(bar);
            pause=new CheckBox {Text="Pause autotext",AutoSize=true,Padding=new Padding(6,7,0,0)};bar.Controls.Add(pause);pause.CheckedChanged+=delegate {prefs.Paused=pause.Checked;if(autotext!=null) {autotext.Enabled=!pause.Checked;autotext.Reset();}UpdateActivity();SavePreferences();};
            var split=new SplitContainer {Size=new Size(900,400),Dock=DockStyle.Fill,SplitterDistance=300};
            snippets.Dock=DockStyle.Fill; snippets.IntegralHeight=false; snippets.ItemHeight=30; split.Panel1.Controls.Add(snippets);
            var detail=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(12,0,0,0)};
            detail.RowStyles.Add(new RowStyle(SizeType.Absolute,35)); detail.RowStyles.Add(new RowStyle(SizeType.Percent,100)); detail.RowStyles.Add(new RowStyle(SizeType.Absolute,50));
            title.Dock=DockStyle.Fill; title.Font=new Font("Segoe UI",13,FontStyle.Bold); detail.Controls.Add(title);
            preview.Dock=DockStyle.Fill; preview.Multiline=true; preview.ReadOnly=true; preview.ScrollBars=ScrollBars.Vertical; preview.BackColor=Color.White; detail.Controls.Add(preview);
            var pasteBar=new FlowLayoutPanel {Dock=DockStyle.Fill}; AddButton(pasteBar,"Insert into app",delegate {Insert();},150); AddButton(pasteBar,"Copy text",delegate {Copy();},120); detail.Controls.Add(pasteBar); split.Panel2.Controls.Add(detail); root.Controls.Add(split);
            activity.AutoSize=true;activity.Padding=new Padding(6,7,0,0);pasteBar.Controls.Add(activity);
            status.Dock=DockStyle.Fill; status.Text="Type a trigger + Space to expand. Ctrl + Alt + Space opens the snippet picker."; root.Controls.Add(status); Controls.Add(root);
            categories.SelectedIndexChanged += delegate { if (!loading) RefreshList(); }; search.TextChanged += delegate {RefreshList();};
            snippets.SelectedIndexChanged += delegate {var s=snippets.SelectedItem as Snippet; title.Text=s==null ? "Select a snippet" : s.Title; preview.Text=s==null ? "" : s.Text;};
            snippets.DoubleClick += delegate {Insert();};
            search.KeyDown += delegate(object sender,KeyEventArgs e) {if (e.KeyCode==Keys.Down && snippets.Items.Count>0) {snippets.Focus(); snippets.SelectedIndex=0; e.SuppressKeyPress=true;} else if (e.KeyCode==Keys.Enter) {Insert();e.SuppressKeyPress=true;}};
            snippets.KeyDown += delegate(object sender,KeyEventArgs e) {if(e.KeyCode==Keys.Enter) {Insert();e.SuppressKeyPress=true;}};
            KeyPreview=true; KeyDown += delegate(object sender,KeyEventArgs e) {if(e.KeyCode==Keys.Escape) {target=IntPtr.Zero;Hide();e.SuppressKeyPress=true;}};
            BuildMenus();
            floating=new FloatingForm(this); floating.Icon=Icon; floating.TopMost=prefs.AlwaysOnTop;
            RestoreWindowBounds(this,prefs.MainX,prefs.MainY,prefs.MainWidth,prefs.MainHeight);
            RestoreWindowBounds(floating,prefs.FloatX,prefs.FloatY,prefs.FloatWidth,prefs.FloatHeight);
            ResizeEnd+=delegate {SavePreferences();};floating.ResizeEnd+=delegate {SavePreferences();};
            var menu=new ContextMenuStrip();
            menu.Items.Add("Open IT Help Desk Word Inserter",null,delegate {target=IntPtr.Zero;ShowManager();});
            menu.Items.Add("Floating reference",null,delegate {SetFloating(!prefs.FloatingVisible);});
            menu.Items.Add("Pause / resume autotext",null,delegate {pause.Checked=!pause.Checked;});
            menu.Items.Add("Read Me",null,delegate {ReadMe();}); menu.Items.Add("About",null,delegate {About();});
            menu.Items.Add("Exit",null,delegate {quitting=true;Close();});
            tray=new NotifyIcon {Icon=Icon,Text="IT Help Desk Word Inserter",ContextMenuStrip=menu,Visible=true}; tray.DoubleClick += delegate {target=IntPtr.Zero;ShowManager();};
            FormClosing += delegate(object sender,FormClosingEventArgs e) {if(!quitting && e.CloseReason==CloseReason.UserClosing) {e.Cancel=true;target=IntPtr.Zero;SavePreferences();Hide();}};
            FormClosed += delegate {SavePreferences();floating.Dispose();if(insertion!=null)insertion.Dispose();if(autotext!=null)autotext.Dispose();tray.Dispose();}; ReloadCategories(null);
            Shown += delegate {if(autotext==null) {autotext=new Autotext(this);autotext.Enabled=autotext.Available && !prefs.Paused;if(!autotext.Available)MessageBox.Show("Windows blocked autotext detection. The shortcut picker and Copy text remain available.");}UpdateActivity();if(prefs.FloatingVisible)floating.Show();};
            pause.Checked=prefs.Paused;preferencesReady=true;ApplyTheme();UpdateActivity();
        }
        internal bool AlwaysOnTop {get {return prefs.AlwaysOnTop;}}
        Icon LoadIcon() {try {return new Icon(Path.Combine(Program.BaseDirectory,"IT-Help-Desk.ico"));}catch {return SystemIcons.Application;}}
        internal void OpenMain() {target=IntPtr.Zero;ShowManager();}
        internal void NewFromFloating() {OpenMain();Edit(false);}
        internal void TogglePause() {pause.Checked=!pause.Checked;}
        internal void SetAlwaysOnTop(bool value) {prefs.AlwaysOnTop=value;if(floating!=null)floating.TopMost=value;SavePreferences();}
        internal void SetFloating(bool value) {
            prefs.FloatingVisible=value;if(floatItem!=null)floatItem.Checked=value;
            if(floating!=null) {if(value)floating.Show();else floating.Hide();}SavePreferences();
        }
        void ReadMe() {
            try {Process.Start(new ProcessStartInfo(Path.Combine(Program.BaseDirectory,"README.txt")) {UseShellExecute=true});}
            catch(Exception ex) {MessageBox.Show(this,"Could not open README.txt. Keep it in the program folder.\n"+ex.Message,"Read Me");}
        }
        void About() {
            MessageBox.Show(this,"IT Help Desk Word Inserter\nVersion 1.06 - BAT / PowerShell edition\n\nReusable incident-ticket text, searchable snippets, typed triggers, and a configurable floating reference window.\n\nCreated by Luiz Holt\n\nWindows PowerShell 5.1 required. No registration required.\nStore only information permitted by your organization's policies.","About IT Help Desk Word Inserter",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
        void BuildMenus() {
            var menu=new MenuStrip();var file=new ToolStripMenuItem("File");
            file.DropDownItems.Add("New snippet",null,delegate {Edit(false);});file.DropDownItems.Add("Import backup...",null,delegate {Import();});file.DropDownItems.Add("Export backup...",null,delegate {Export();});
            file.DropDownItems.Add("Add IT ticket samples",null,delegate {AddTicketSamples();});
            file.DropDownItems.Add(new ToolStripSeparator());file.DropDownItems.Add("Exit",null,delegate {quitting=true;Close();});menu.Items.Add(file);
            var view=new ToolStripMenuItem("View");darkItem=new ToolStripMenuItem("Dark mode") {Checked=prefs.Dark,CheckOnClick=true};darkItem.CheckedChanged+=delegate {prefs.Dark=darkItem.Checked;ApplyTheme();SavePreferences();};view.DropDownItems.Add(darkItem);
            floatItem=new ToolStripMenuItem("Show floating window") {Checked=prefs.FloatingVisible};floatItem.Click+=delegate {SetFloating(!prefs.FloatingVisible);};view.DropDownItems.Add(floatItem);
            view.DropDownItems.Add("Choose floating snippets...",null,delegate {ConfigureFloating();});
            var top=new ToolStripMenuItem("Floating window always on top") {Checked=prefs.AlwaysOnTop,CheckOnClick=true};top.CheckedChanged+=delegate {SetAlwaysOnTop(top.Checked);};view.DropDownItems.Add(top);
            view.DropDownOpening+=delegate {top.Checked=prefs.AlwaysOnTop;};menu.Items.Add(view);
            var tools=new ToolStripMenuItem("Tools");pauseItem=new ToolStripMenuItem("Pause autotext");pauseItem.Click+=delegate {TogglePause();};tools.DropDownItems.Add(pauseItem);tools.DropDownItems.Add("Manage categories...",null,delegate {ManageCategories();});menu.Items.Add(tools);
            var help=new ToolStripMenuItem("Help");help.DropDownItems.Add("Read Me",null,delegate {ReadMe();});help.DropDownItems.Add("About",null,delegate {About();});menu.Items.Add(help);Controls.Add(menu);MainMenuStrip=menu;
        }
        void UpdateActivity() {
            string value=autotext==null ? "Autotext: starting" : !autotext.Available ? "Autotext: unavailable" : prefs.Paused ? "Autotext: PAUSED" : "Autotext: ON";
            activity.Text=value;if(floating!=null)floating.SetActivity(value);if(pauseItem!=null)pauseItem.Checked=prefs.Paused;
        }
        void ApplyTheme() {Theme.Apply(this,prefs.Dark);if(floating!=null)Theme.Apply(floating,prefs.Dark);if(tray!=null && tray.ContextMenuStrip!=null)Theme.Apply(tray.ContextMenuStrip,prefs.Dark);}
        static void RestoreWindowBounds(Form form,int x,int y,int width,int height) {
            if(x==Int32.MinValue)return;
            Rectangle area=Screen.FromPoint(new Point(x,y)).WorkingArea;
            width=Math.Max(form.MinimumSize.Width,Math.Min(width,area.Width));height=Math.Max(form.MinimumSize.Height,Math.Min(height,area.Height));
            form.StartPosition=FormStartPosition.Manual;form.Bounds=new Rectangle(Math.Max(area.Left,Math.Min(x,area.Right-width)),Math.Max(area.Top,Math.Min(y,area.Bottom-height)),width,height);
        }
        void SavePreferences() {
            if(!preferencesReady)return;
            Rectangle main=WindowState==FormWindowState.Normal ? Bounds : base.RestoreBounds;
            prefs.MainX=main.X;prefs.MainY=main.Y;prefs.MainWidth=main.Width;prefs.MainHeight=main.Height;
            if(floating!=null) {Rectangle rect=floating.WindowState==FormWindowState.Normal ? floating.Bounds : floating.RestoreBounds;prefs.FloatX=rect.X;prefs.FloatY=rect.Y;prefs.FloatWidth=rect.Width;prefs.FloatHeight=rect.Height;}
            try {prefs.Save(prefsPath);}catch(Exception ex) {status.Text="Could not save preferences: "+ex.Message;}
        }
        internal void ConfigureFloating() {
            using(var dialog=new Form {Text="Choose floating snippets",Size=new Size(520,540),MinimumSize=new Size(480,350),StartPosition=FormStartPosition.CenterParent,Font=Font,Icon=Icon}) {
                var list=new CheckedListBox {Dock=DockStyle.Fill,CheckOnClick=true};
                var sorted=data.Snippets.OrderBy(x=>x.Title).ToList();foreach(var s in sorted)list.Items.Add(s,!prefs.HiddenIds.Contains(s.Id));
                var bar=new FlowLayoutPanel {Dock=DockStyle.Bottom,Height=48,Padding=new Padding(5)};
                var all=new Button {Text="Select all",Width=100};all.Click+=delegate {for(int i=0;i<list.Items.Count;i++)list.SetItemChecked(i,true);};
                var none=new Button {Text="Select none",Width=100};none.Click+=delegate {for(int i=0;i<list.Items.Count;i++)list.SetItemChecked(i,false);};
                var save=new Button {Text="Save",Width=100,DialogResult=DialogResult.OK};var cancel=new Button {Text="Cancel",Width=100,DialogResult=DialogResult.Cancel};
                bar.Controls.AddRange(new Control[]{all,none,save,cancel});dialog.Controls.Add(list);dialog.Controls.Add(bar);dialog.AcceptButton=save;dialog.CancelButton=cancel;Theme.Apply(dialog,prefs.Dark);
                if(dialog.ShowDialog(this)!=DialogResult.OK)return;
                prefs.HiddenIds.Clear();for(int i=0;i<sorted.Count;i++)if(!list.GetItemChecked(i))prefs.HiddenIds.Add(sorted[i].Id);
                floating.RefreshSnippets(data.Snippets,prefs.HiddenIds);SavePreferences();
            }
        }

        protected override void OnHandleCreated(EventArgs e) {
            base.OnHandleCreated(e); hotkey=Native.RegisterHotKey(Handle,1,0x4003,0x20);
            if(!hotkey) MessageBox.Show("Ctrl + Alt + Space is in use by another app. Use the tray icon to open this manager and Copy text to paste manually.","Shortcut unavailable");
        }
        protected override void OnHandleDestroyed(EventArgs e) {if(hotkey) Native.UnregisterHotKey(Handle,1);base.OnHandleDestroyed(e);}
        protected override void WndProc(ref Message m) {
            if(m.Msg==0x312 && m.WParam.ToInt32()==1) {IntPtr active=Native.GetForegroundWindow(); target=active==Handle ? IntPtr.Zero : active; ShowManager();}
            base.WndProc(ref m);
        }
        void ShowManager() {Show();WindowState=FormWindowState.Normal;Activate();search.Focus();search.SelectAll();}
        void AddButton(FlowLayoutPanel panel,string text,EventHandler click,int width=100) {var b=new Button {Text=text,Width=width,Height=34,FlatStyle=FlatStyle.Flat,BackColor=Color.White};b.Click+=click;panel.Controls.Add(b);}
        bool Persist() {if(readOnly) {MessageBox.Show("Saving is disabled until your existing data is recovered.");return false;} try {data.Write(dataPath);return true;} catch(Exception ex) {MessageBox.Show("Could not save your changes. Keep the app open and export a backup.\n"+ex.Message);return false;}}
        void ReloadCategories(string selected) {loading=true;categories.Items.Clear();categories.Items.Add("All categories");categories.Items.AddRange(data.Categories.Cast<object>().ToArray());categories.SelectedItem=selected; if(categories.SelectedIndex<0) categories.SelectedIndex=0;loading=false;RefreshList();}
        void RefreshList() {
            var selected=snippets.SelectedItem as Snippet; string q=search.Text.Trim(); string c=categories.SelectedIndex>0 ? (string)categories.SelectedItem : null;
            snippets.BeginUpdate();snippets.Items.Clear();
            foreach(var s in data.Snippets.Where(s => (c==null || s.Category==c) && (q.Length==0 || s.Title.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0 || s.Text.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0 || (s.Trigger ?? "").IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0 || s.Category.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0)).OrderBy(s=>s.Title)) snippets.Items.Add(s);
            if(selected!=null && snippets.Items.Contains(selected)) snippets.SelectedItem=selected;else if(snippets.Items.Count>0) snippets.SelectedIndex=0;
            if(snippets.Items.Count==0) {title.Text="No snippets found";preview.Text="";}snippets.EndUpdate();if(floating!=null)floating.RefreshSnippets(data.Snippets,prefs.HiddenIds);
        }
        void Edit(bool existing) {
            if(readOnly) return;var s=existing ? snippets.SelectedItem as Snippet : null;if(existing && s==null) return;
            using(var editor=new Editor(data.Categories,s)) {Theme.Apply(editor,prefs.Dark);editor.Icon=Icon;if(!existing && categories.SelectedIndex>0) editor.CategoryBox.SelectedItem=categories.SelectedItem;
                while(editor.ShowDialog(this)==DialogResult.OK) {
                    string trigger=editor.TriggerBox.Text;
                    if(trigger.Length>0 && data.Snippets.Any(other=>other!=s && String.Equals(other.Trigger,trigger,StringComparison.OrdinalIgnoreCase))) {MessageBox.Show("That trigger is already assigned. Choose another one.");continue;}
                    if(s==null) {s=new Snippet();data.Snippets.Add(s);} s.Title=editor.TitleBox.Text.Trim();s.Category=(string)editor.CategoryBox.SelectedItem;s.Text=editor.BodyBox.Text;s.Trigger=trigger;break;
                }
                if(editor.DialogResult!=DialogResult.OK)return;
                Persist();ReloadCategories(s.Category);snippets.SelectedItem=s;
            }
        }
        void DeleteSnippet() {if(readOnly) return;var s=snippets.SelectedItem as Snippet;if(s==null) return;if(MessageBox.Show(this,"Delete '"+s.Title+"'?","Delete snippet",MessageBoxButtons.YesNo)==DialogResult.Yes) {data.Snippets.Remove(s);Persist();RefreshList();}}
        string Ask(string caption,string initial) {using(var dialog=new Form {Text=caption,Size=new Size(420,165),StartPosition=FormStartPosition.CenterParent,Font=Font,FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false}) {var input=new TextBox {Text=initial,Location=new Point(20,20),Width=365};var ok=new Button {Text="OK",Location=new Point(215,65),DialogResult=DialogResult.OK};var cancel=new Button {Text="Cancel",Location=new Point(300,65),DialogResult=DialogResult.Cancel};dialog.Controls.AddRange(new Control[]{input,ok,cancel});dialog.AcceptButton=ok;dialog.CancelButton=cancel;Theme.Apply(dialog,prefs.Dark);return dialog.ShowDialog(this)==DialogResult.OK ? input.Text.Trim() : null;}}
        void ManageCategories() {
            if(readOnly) return;
            using(var dialog=new Form {Text="Manage categories",Size=new Size(450,360),StartPosition=FormStartPosition.CenterParent,Font=Font}) {
                var list=new ListBox {Dock=DockStyle.Fill};var bar=new FlowLayoutPanel {Dock=DockStyle.Bottom,Height=48};dialog.Controls.Add(list);dialog.Controls.Add(bar);
                Action refresh=delegate {list.Items.Clear();list.Items.AddRange(data.Categories.Cast<object>().ToArray());if(list.Items.Count>0)list.SelectedIndex=0;};refresh();
                AddButton(bar,"Add",delegate {string name=Ask("New category","");if(String.IsNullOrWhiteSpace(name))return;if(data.Categories.Any(c=>String.Equals(c,name,StringComparison.OrdinalIgnoreCase))) {MessageBox.Show("That category already exists.");return;}data.Categories.Add(name);Persist();refresh();ReloadCategories(name);});
                AddButton(bar,"Rename",delegate {string old=list.SelectedItem as string;if(old==null)return;string name=Ask("Rename category",old);if(String.IsNullOrWhiteSpace(name)||name==old)return;if(data.Categories.Any(c=>c!=old && String.Equals(c,name,StringComparison.OrdinalIgnoreCase))) {MessageBox.Show("That category already exists.");return;}data.Categories[data.Categories.IndexOf(old)]=name;foreach(var s in data.Snippets.Where(s=>s.Category==old))s.Category=name;Persist();refresh();ReloadCategories(name);});
                AddButton(bar,"Delete",delegate {string old=list.SelectedItem as string;if(old==null)return;if(data.Categories.Count==1) {MessageBox.Show("Keep at least one category.");return;}string destination=data.Categories.First(c=>c!=old);if(MessageBox.Show(dialog,"Delete this category? Its snippets will move to '"+destination+"'.","Delete category",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;foreach(var s in data.Snippets.Where(s=>s.Category==old))s.Category=destination;data.Categories.Remove(old);Persist();refresh();ReloadCategories(destination);});
                Theme.Apply(dialog,prefs.Dark);dialog.ShowDialog(this);
            }
        }
        bool Copy() {var s=snippets.SelectedItem as Snippet;if(s==null)return false;try {Clipboard.SetText(s.Text,TextDataFormat.UnicodeText);status.Text="Copied: "+s.Title+". Paste with Ctrl + V.";return true;}catch(Exception ex) {MessageBox.Show("The clipboard is busy. Try again.\n"+ex.Message);return false;}}
        internal Snippet FindTrigger(string typed) {return String.IsNullOrEmpty(typed) ? null : data.Snippets.FirstOrDefault(s=>!String.IsNullOrEmpty(s.Trigger) && String.Equals(s.Trigger,typed,StringComparison.OrdinalIgnoreCase));}
        void BeginInsertion(string text,int erase,IntPtr destination,bool trigger) {
            if(insertion!=null)return;
            int stamp=autotext==null ? 0 : autotext.Generation;
            Func<bool> unchanged=delegate {return (autotext==null || autotext.Generation==stamp) && (!trigger || (autotext!=null && autotext.Enabled));};
            insertion=new ClipboardInserter(text,erase,destination,unchanged,delegate(string message) {insertion=null;status.Text=message;});
        }
        internal void ExpandTrigger(Snippet s) {
            BeginInsertion(s.Text+" ",s.Trigger.Length+1,Native.GetForegroundWindow(),true);
        }
        void Insert() {
            if(snippets.SelectedItem==null)return;
            if(target==IntPtr.Zero || !Native.IsWindow(target)) {Copy();status.Text="Copied. To insert automatically, open this manager from the destination app with Ctrl + Alt + Space.";return;}
            string text=((Snippet)snippets.SelectedItem).Text;IntPtr destination=target;target=IntPtr.Zero;Hide();
            if(!Native.SetForegroundWindow(destination)) {ShowManager();status.Text="Could not return to your destination. Use Copy text and paste manually.";return;}
            var timer=new System.Windows.Forms.Timer {Interval=200};
            timer.Tick += delegate {timer.Stop();timer.Dispose();if(Native.GetForegroundWindow()!=destination) {ShowManager();status.Text="Automatic insertion was stopped because the destination changed.";}else BeginInsertion(text,0,destination,false);};timer.Start();
        }
        void Export() {using(var dialog=new SaveFileDialog {Filter="Snippet backup (*.json)|*.json",FileName="snippet-backup.json"}) {if(dialog.ShowDialog(this)!=DialogResult.OK)return;try {data.Write(dialog.FileName);status.Text="Backup exported.";}catch(Exception ex) {MessageBox.Show(ex.Message,"Export failed");}}}
        DialogResult ChooseImportMode(int count) {
            using(var choice=new Form {Text="Import snippets",Size=new Size(570,280),FormBorderStyle=FormBorderStyle.FixedDialog,StartPosition=FormStartPosition.CenterParent,MaximizeBox=false,MinimizeBox=false,Font=Font,Icon=Icon}) {
                var explanation=new Label {Dock=DockStyle.Fill,Padding=new Padding(18),Text="This backup contains "+count+" snippets.\n\nMerge: keep your current snippets and add imported items. Exact duplicates are skipped. Conflicting imported triggers are cleared so you can assign new ones.\n\nReplace: remove the current collection and use only the backup."};
                var bar=new FlowLayoutPanel {Dock=DockStyle.Bottom,Height=55,FlowDirection=FlowDirection.RightToLeft,Padding=new Padding(10)};
                var cancel=new Button {Text="Cancel",Width=105,Height=32,DialogResult=DialogResult.Cancel};
                var replace=new Button {Text="Replace",Width=105,Height=32,DialogResult=DialogResult.No};
                var merge=new Button {Text="Merge",Width=105,Height=32,DialogResult=DialogResult.Yes};
                bar.Controls.AddRange(new Control[]{cancel,replace,merge});choice.Controls.Add(explanation);choice.Controls.Add(bar);choice.AcceptButton=merge;choice.CancelButton=cancel;Theme.Apply(choice,prefs.Dark);return choice.ShowDialog(this);
            }
        }
        void CommitImport(Store incoming,bool merge) {
            var previous=data;MergeResult result=merge ? Store.Merge(data,incoming) : null;
            data=merge ? result.Collection : incoming;
            if(!Persist()) {data=previous;return;}
            ReloadCategories(null);
            if(!merge) {status.Text="Collection replaced with "+data.Snippets.Count+" imported snippets.";return;}
            status.Text="Merged: "+result.Added+" added, "+result.Skipped+" duplicates skipped, "+result.Conflicts.Count+" trigger conflicts.";
            string message=result.Added+" snippets added.\n"+result.Skipped+" exact duplicates skipped.\nYour existing snippets and triggers were kept.";
            if(result.Conflicts.Count>0) {
                message+="\n\nThese imported snippets were added with blank triggers because those triggers were already in use. Select each in the main window and click Edit to assign a different trigger:\n\n"+String.Join("\n",result.Conflicts.Take(20).ToArray());
                if(result.Conflicts.Count>20)message+="\n...and "+(result.Conflicts.Count-20)+" more. Find imported snippets without triggers in the main list.";
            }
            MessageBox.Show(this,message,"Merge complete",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
        void AddTicketSamples() {
            if(readOnly)return;
            if(MessageBox.Show(this,"Add the 25 built-in IT ticket samples to your current collection? Your current items will be kept and exact duplicates skipped.","Add IT ticket samples",MessageBoxButtons.OKCancel,MessageBoxIcon.Question)!=DialogResult.OK)return;
            try {CommitImport(Store.CreateSamples(),true);}catch(Exception ex) {MessageBox.Show(this,ex.Message,"Could not add samples");}
        }
        void Import() {
            if(readOnly)return;using(var dialog=new OpenFileDialog {Filter="Snippet backup (*.json)|*.json"}) {
                if(dialog.ShowDialog(this)!=DialogResult.OK)return;
                try {
                    var incoming=Store.Read(dialog.FileName);var mode=ChooseImportMode(incoming.Snippets.Count);
                    if(mode==DialogResult.Cancel)return;
                    if(mode==DialogResult.No && MessageBox.Show(this,"Replace ALL current categories and snippets with this backup?\n\nChoose Cancel to keep your current collection. Use Merge to add items instead.","Confirm replacement",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning)!=DialogResult.OK)return;
                    if(mode==DialogResult.Yes || mode==DialogResult.No)CommitImport(incoming,mode==DialogResult.Yes);
                }catch(Exception ex) {MessageBox.Show(this,ex.Message,"Import failed");}
            }
        }
    }
}
