@echo off
if /i "%~1"=="--minimized" goto run
start "IT Help Desk Word Inserter" /min "%ComSpec%" /d /c ""%~f0" --minimized"
exit /b
:run
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -STA -WindowStyle Minimized -ExecutionPolicy Bypass -File "%~dp0Snippet-Manager.ps1"
exit /b
