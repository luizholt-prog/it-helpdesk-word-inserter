Option Explicit
Dim shell, files, launcher, command
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
launcher = files.BuildPath(files.GetParentFolderName(WScript.ScriptFullName), "Start-Snippet-Manager.bat")
command = Chr(34) & shell.ExpandEnvironmentStrings("%ComSpec%") & Chr(34) & " /d /c " & Chr(34) & Chr(34) & launcher & Chr(34) & " --minimized" & Chr(34)
shell.Run command, 7, False
