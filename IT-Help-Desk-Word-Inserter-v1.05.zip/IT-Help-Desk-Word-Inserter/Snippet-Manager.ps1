﻿$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    Add-Type -AssemblyName System.Runtime.Serialization
    Add-Type -AssemblyName System.Xml
    $source = [System.IO.File]::ReadAllText((Join-Path $PSScriptRoot 'SnippetManager.cs'))
    Add-Type -TypeDefinition $source -ReferencedAssemblies System,System.Core,System.Xml,System.Windows.Forms,System.Drawing,System.Runtime.Serialization
    # Create the desktop shortcut once, after the source compiles successfully.
    $settingsDirectory = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'ITHelpDeskWordInserter'
    [System.IO.Directory]::CreateDirectory($settingsDirectory) | Out-Null
    $shortcutMarker = Join-Path $settingsDirectory 'desktop-shortcut-created.txt'
    if (-not (Test-Path -LiteralPath $shortcutMarker)) {
        try {
            $desktopDirectory = [Environment]::GetFolderPath('DesktopDirectory')
            $shortcutFile = Join-Path $desktopDirectory 'IT Help Desk Word Inserter.lnk'
            $shortcutShell = New-Object -ComObject WScript.Shell
            $shortcut = $shortcutShell.CreateShortcut($shortcutFile)
            $shortcut.TargetPath = Join-Path $PSScriptRoot 'Start-Snippet-Manager.bat'
            $shortcut.WorkingDirectory = $PSScriptRoot
            $shortcut.WindowStyle = 7
            $shortcut.Description = 'IT Help Desk Word Inserter - Created by Luiz Holt'
            $shortcut.IconLocation = (Join-Path $PSScriptRoot 'IT-Help-Desk.ico') + ',0'
            $shortcut.Save()
            [System.IO.File]::WriteAllText($shortcutMarker, $shortcutFile)
        } catch {
            [System.Windows.Forms.MessageBox]::Show('The desktop shortcut could not be created. The app will still open. You can launch it using Start-Snippet-Manager.bat.' + [Environment]::NewLine + $_.Exception.Message, 'Desktop shortcut') | Out-Null
        }
    }
    [SnippetManager.Program]::Run($PSScriptRoot)
} catch {
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'IT Help Desk Word Inserter could not start') | Out-Null
    exit 1
}
